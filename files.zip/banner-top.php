<center>
<img src="img/reklama728x90.jpg" style="max-width:100%;width:728px;">
</center>