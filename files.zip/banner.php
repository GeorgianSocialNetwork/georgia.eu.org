<center>

</center>
<div style='text-align:center;position:fixed;bottom:3px;center:3px;width:100%;z-index:999999;cursor:pointer;line-height:0;display:block;'>
</tr><tr><td height=10 colspan=3 align=center>
<br>

<!-- BOOM.GE COUNTER CODE START -->

<script type=text/javascript src="http://links.boom.ge/jc.php?id=61889"></script>

<noscript><a href="http://top.boom.ge/index.php?id=61889" target="_blank"><img src="http://links.boom.ge/nojs.php?id=61889" border="0" alt="BOOM.GE"></a></noscript>

<!-- BOOM.GE COUNTER CODE END -->

<br>

<!-- TOP.GE COUNTER CODE -->

<script language="JavaScript" type="text/javascript" src="//counter.top.ge/cgi-bin/cod?100+115138"></script>

<noscript>

<a target="_top" href="http://counter.top.ge/cgi-bin/showtop?115138">

<img src="//counter.top.ge/cgi-bin/count?ID:115138+JS:false" border="0" alt="TOP.GE" /></a>

</noscript>

<!-- / END OF TOP.GE COUNTER CODE -->

<br>

</td></tr>
</table></div>