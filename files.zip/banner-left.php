<div id="myad"> 
<div style="margin: 5px !important; float: left !important;"> 
<img src="img/reklama160x500.jpg" style="max-width:100%;width:250px;">
</div>
</div>